![Header Image](https://www.omegacraft.games/img/omegacraft.png)

# Omegacraft Season 4 Resource Pack
## Resource Pack for Minecraft: Java Edition

[![License: CC BY-NC-SA 4.0](https://img.shields.io/badge/License-CC%20BY--NC--SA%204.0-brightgreen.svg)](https://creativecommons.org/licenses/by-nc-sa/4.0/)
[![Release](https://img.shields.io/github/v/release/Bret06/Omegacraft-Season-4-Resource-Pack?color=brightgreen&label=Release&cacheSeconds=3600)](https://github.com/Bret06/Omegacraft-Season-4-Resource-Pack/releases)

This Resource Pack is the server resource pack created for the Minecraft server Omegacraft!

## Omegacraft Info

* [Omegacraft Website](https://www.omegacraft.games/)
* [Omegacraft Discord](https://discord.gg/9qZuW9s44B)
